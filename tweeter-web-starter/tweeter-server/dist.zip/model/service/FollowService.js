"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FollowService = void 0;
const tweeter_shared_1 = require("tweeter-shared");
class FollowService {
    async loadMoreFollowees(authToken, userAlias, pageSize, lastUserItem) {
        // TODO: Replace with the result of calling server
        return this.getFakeData(lastUserItem, pageSize, userAlias);
    }
    async loadMoreFollowers(authToken, userAlias, pageSize, lastUserItem) {
        // TODO: Replace with the result of calling server
        return this.getFakeData(lastUserItem, pageSize, userAlias);
    }
    async getFakeData(lastUserItem, pageSize, userAlias) {
        const [items, hasMore] = tweeter_shared_1.FakeData.instance.getPageOfUsers(tweeter_shared_1.User.fromDTO(lastUserItem), pageSize, userAlias);
        const dtos = items.map((user) => user.DTO);
        return [dtos, hasMore];
    }
}
exports.FollowService = FollowService;
